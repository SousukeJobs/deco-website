// SHOP専用：左右の矢印と点で商品画像を切り替える。
const shopGallery = document.querySelector('.shop-gallery');

if (shopGallery) {
  const track = shopGallery.querySelector('.shop-gallery__track');
  const slides = shopGallery.querySelectorAll('.shop-gallery__slide');
  const dots = shopGallery.querySelectorAll('.shop-gallery__dot');
  const previous = shopGallery.querySelector('.shop-gallery__arrow--previous');
  const next = shopGallery.querySelector('.shop-gallery__arrow--next');
  const announcement = shopGallery.querySelector('.shop-gallery__announcement');

  if (track && slides.length && dots.length === slides.length && previous && next && announcement) {
    let currentIndex = 0;

    const showSlide = (index) => {
      const nextIndex = Math.max(0, Math.min(slides.length - 1, index));
      if (nextIndex === currentIndex) return;
      const focusedControl = document.activeElement;
      currentIndex = nextIndex;
      track.style.transform = `translateX(-${currentIndex * 100}%)`;
      slides.forEach((slide, slideIndex) => {
        slide.setAttribute('aria-hidden', String(slideIndex !== currentIndex));
      });
      dots.forEach((dot, dotIndex) => {
        dot.setAttribute('aria-pressed', String(dotIndex === currentIndex));
      });
      previous.disabled = currentIndex === 0;
      next.disabled = currentIndex === slides.length - 1;
      announcement.textContent = `${slides[currentIndex].dataset.label}、${currentIndex + 1}枚目、全${slides.length}枚。`;

      // 操作した矢印が端で非表示になったら、使える矢印にフォーカスを移す。
      if (focusedControl === previous && previous.disabled) next.focus({ preventScroll: true });
      if (focusedControl === next && next.disabled) previous.focus({ preventScroll: true });
    };

    previous.addEventListener('click', () => showSlide(currentIndex - 1));
    next.addEventListener('click', () => showSlide(currentIndex + 1));
    dots.forEach((dot, index) => dot.addEventListener('click', () => showSlide(index)));
    shopGallery.addEventListener('keydown', (event) => {
      if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
      event.preventDefault();
      showSlide(currentIndex + (event.key === 'ArrowRight' ? 1 : -1));
    });

    previous.disabled = true;
    next.disabled = slides.length === 1;
    shopGallery.classList.add('is-ready');
  }
}
